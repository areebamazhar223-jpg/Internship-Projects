
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";

import MainLayout from "../components/layout/MainLayout";
import Dashboard from "../pages/Dashboard";
import NotFound from "../pages/NotFound";

import Login from "../features/auth/Login";
import ProtectedRoute from "../features/auth/ProtectedRoute";

import Patients from "../features/patients/Patients";
import Doctors from "../features/doctors/Doctors";
import Appointments from "../features/appointments/Appointments";
import Billing from "../features/billing/Billing";
import Settings from "../features/settings/Settings";

function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public Route */}
        <Route path="/login" element={<Login />} />

        {/* Protected Routes */}
        <Route element={<ProtectedRoute />}>
          <Route element={<MainLayout />}>
            <Route
              path="/"
              element={<Navigate to="/dashboard" replace />}
            />

            <Route
              path="/dashboard"
              element={<Dashboard />}
            />

            {/* Patients */}
            <Route
              element={
                <ProtectedRoute
                  allowedRoles={[
                    "Admin",
                    "Doctor",
                    "Receptionist",
                  ]}
                />
              }
            >
              <Route
                path="/patients"
                element={<Patients />}
              />
            </Route>

            {/* Other Modules */}
            <Route path="/doctors" element={<Doctors />} />

            <Route
              path="/appointments"
              element={<Appointments />}
            />

            <Route path="/billing" element={<Billing />} />

            <Route path="/settings" element={<Settings />} />
          </Route>
        </Route>

        {/* Fallback Route */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default AppRoutes;
