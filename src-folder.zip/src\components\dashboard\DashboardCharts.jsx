
import { useMemo, useState } from "react";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";

import "./DashboardCharts.css";

const MONTHS = [
  "Jan", "Feb", "Mar", "Apr",
  "May", "Jun", "Jul", "Aug",
  "Sep", "Oct", "Nov", "Dec",
];

function parseLocalDate(dateString) {
  if (!dateString) return null;

  const date = new Date(`${dateString}T00:00:00`);

  return Number.isNaN(date.getTime()) ? null : date;
}

function getWeekData(appointments, weekOffset = 0) {
  const today = new Date();

  // Find Monday of current week
  const currentDay = today.getDay();
  const daysFromMonday = currentDay === 0 ? 6 : currentDay - 1;

  const monday = new Date(today);
  monday.setDate(today.getDate() - daysFromMonday);
  monday.setHours(0, 0, 0, 0);

  // Move to selected week
  monday.setDate(monday.getDate() + weekOffset * 7);

  return Array.from({ length: 7 }, (_, index) => {
    const currentDate = new Date(monday);
    currentDate.setDate(monday.getDate() + index);

    const dateString = [
      currentDate.getFullYear(),
      String(currentDate.getMonth() + 1).padStart(2, "0"),
      String(currentDate.getDate()).padStart(2, "0"),
    ].join("-");

    const count = appointments.filter(
      (appointment) =>
        appointment.date === dateString &&
        appointment.status !== "Cancelled",
    ).length;

    return {
      day: currentDate.toLocaleDateString("en", {
        weekday: "short",
      }),
      appointments: count,
    };
  });
}

function getMonthlyPatientData(patients, selectedYear) {
  return MONTHS.map((month, index) => {
    const count = patients.filter((patient) => {
      const registrationDate = parseLocalDate(patient.date);

      return (
        registrationDate &&
        registrationDate.getFullYear() === selectedYear &&
        registrationDate.getMonth() === index
      );
    }).length;

    return {
      month,
      patients: count,
    };
  });
}

function DashboardCharts({
  patients = [],
  appointments = [],
}) {
  const currentYear = new Date().getFullYear();

  const [weekFilter, setWeekFilter] = useState("current");
  const [selectedYear, setSelectedYear] = useState(
    String(currentYear),
  );

  // Weekly appointment data
  const appointmentData = useMemo(
    () =>
      getWeekData(
        appointments,
        weekFilter === "previous" ? -1 : 0,
      ),
    [appointments, weekFilter],
  );

  // Monthly patient registration data
  const patientData = useMemo(
    () =>
      getMonthlyPatientData(
        patients,
        Number(selectedYear),
      ),
    [patients, selectedYear],
  );

  return (
    <div className="dashboard-charts">
      {/* Appointments Chart */}
      <div className="chart-card">
        <div className="chart-header">
          <div>
            <h3>Appointments Overview</h3>
            <p>Weekly appointment activity</p>
          </div>

          <select
            className="chart-filter"
            value={weekFilter}
            onChange={(event) =>
              setWeekFilter(event.target.value)
            }
            aria-label="Appointments chart period"
          >
            <option value="current">This Week</option>
            <option value="previous">Last Week</option>
          </select>
        </div>

        <div className="chart-container">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={appointmentData}
              margin={{
                top: 10,
                right: 10,
                left: -20,
                bottom: 0,
              }}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                vertical={false}
                stroke="#edf1ee"
              />

              <XAxis
                dataKey="day"
                axisLine={false}
                tickLine={false}
                tick={{ fill: "#718078", fontSize: 12 }}
                dy={10}
              />

              <YAxis
                allowDecimals={false}
                axisLine={false}
                tickLine={false}
                tick={{ fill: "#718078", fontSize: 11 }}
              />

              <Tooltip
                cursor={{ fill: "#f0f8f4" }}
                contentStyle={{
                  borderRadius: "10px",
                  border: "1px solid #e8eeea",
                  fontSize: "12px",
                }}
              />

              <Bar
                dataKey="appointments"
                name="Appointments"
                fill="#075b46"
                radius={[6, 6, 0, 0]}
                barSize={30}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Patient Statistics Chart */}
      <div className="chart-card">
        <div className="chart-header">
          <div>
            <h3>Patient Statistics</h3>
            <p>Monthly patient registrations</p>
          </div>

          <select
            className="chart-filter"
            value={selectedYear}
            onChange={(event) =>
              setSelectedYear(event.target.value)
            }
            aria-label="Patient statistics year"
          >
            <option value={String(currentYear)}>
              {currentYear}
            </option>

            <option value={String(currentYear - 1)}>
              {currentYear - 1}
            </option>
          </select>
        </div>

        <div className="chart-container">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={patientData}
              margin={{
                top: 10,
                right: 10,
                left: -20,
                bottom: 0,
              }}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                vertical={false}
                stroke="#edf1ee"
              />

              <XAxis
                dataKey="month"
                axisLine={false}
                tickLine={false}
                tick={{ fill: "#718078", fontSize: 11 }}
                interval={1}
                dy={10}
              />

              <YAxis
                allowDecimals={false}
                axisLine={false}
                tickLine={false}
                tick={{ fill: "#718078", fontSize: 11 }}
              />

              <Tooltip
                contentStyle={{
                  borderRadius: "10px",
                  border: "1px solid #e8eeea",
                  fontSize: "12px",
                }}
              />

              <Line
                type="monotone"
                dataKey="patients"
                name="New Patients"
                stroke="#ff8b5e"
                strokeWidth={3}
                dot={{
                  fill: "#ff8b5e",
                  strokeWidth: 2,
                  r: 4,
                }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

export default DashboardCharts;
